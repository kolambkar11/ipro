import React from 'react'

function footer() {
  return (
    <div>footer</div>
  )
}

export default footer